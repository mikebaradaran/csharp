﻿namespace LabsSolutions.Lab9;

public enum AnimalType
{
    Fish,
    Amphibian,
    Reptil,
    Mammal,
    Bird,
    Invertebrate
}
