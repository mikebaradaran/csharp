﻿namespace LabsSolutions.Lab4;
public class Program{
    public static void Start()
    {
        Console.WriteLine("Please run the GameApplication Windpws Form program.");
        Console.WriteLine("Or you can create your own Windows Form app and use the");
        Console.WriteLine("Ball class code and ShapeType enum included in this project.");
    }
}
