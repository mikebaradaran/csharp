﻿namespace LabsSolutions.Lab4;
public enum SHAPE_TYPE
{
    Rectangle, 
    ThreeDRectangle, 
    RoundRectangle, 
    Oval, 
    Arc
}
