﻿namespace LabsSolutions.Lab3;
public class RegistrationPlate
{
    string regPlate;
    public RegistrationPlate(string regPlate)
    {
        this.regPlate = regPlate;
    }
}

