﻿namespace LabsSolutions.Lab11;
public class Program{
    public static void Start()
    {
        Console.WriteLine("Please create a Test project for this code");
    }
}
