﻿namespace LabsSolutions.Lab10;
public interface Swimmable
{
    void swim();
}

public interface Flyable
{
    void fly();
}
public interface Moveable
{
    void move();
}

