﻿namespace LabsSolutions;
public class Program
{
    private static void Main(string[] args)
    {
        Lab1.Program.Start();
        Lab2.Program.Start();
        Lab3.Program.Start();
        Lab4.Program.Start();
        Lab5.Program.Start();
        Lab6.Program.Start();
        Lab7.Program.Start();
        Lab8.Program.Start();
        Lab9.Program.Start();
        Lab10.Program.Start();
        Lab11.Program.Start();
    }
}s